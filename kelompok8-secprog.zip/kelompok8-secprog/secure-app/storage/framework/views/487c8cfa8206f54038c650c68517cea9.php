<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="/css/admin.css">
</head>
<body>
    <h1>Admin Dashboard</h1>
    <form action="<?php echo e(route('logout'), false); ?>" method="POST" style="display:inline;">
        <?php echo csrf_field(); ?>
        <button type="submit">Logout</button>
    </form>
    <a href="<?php echo e(route('admin.create'), false); ?>">Add New Item</a>
    <table>
        <tr>
            <th>ID</th>
            <th>Email</th>
            <th>Username</th>
            <th>Password</th>
            <th>Role</th>
            <th>Actions</th>
        </tr>
        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($item->id, false); ?></td>
            <td><?php echo e($item->email, false); ?></td>
            <td><?php echo e($item->username, false); ?></td>
            <td><?php echo e($item->password, false); ?></td>
            <td><?php echo e($item->role, false); ?></td>
            <td>
                <a href="<?php echo e(route('admin.edit', $item->id), false); ?>">Edit</a>
                <form action="<?php echo e(route('admin.delete', $item->id), false); ?>" method="POST" style="display:inline;">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit">Delete</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</body>
</html>
<?php /**PATH C:\laragon\www\secure-app\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>